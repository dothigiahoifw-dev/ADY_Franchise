#!/usr/bin/env python3
"""Du bao E0 (OLS log_open_prev) tu artifact e0_fitted.json. Chi dung thu vien chuan (json, csv, math).
Pipeline cua cau hinh E0 da khoa; KHONG phai phuong an da chung minh vuot baseline.

Vi du:
  python predict_e0.py --artifact e0_fitted.json --open-prev 20000000
  python predict_e0.py --artifact e0_fitted.json --input example_input.csv --output example_output.csv
  python predict_e0.py --artifact e0_fitted.json --check reference_predictions_task4.csv --check-output artifact_check.csv
Dau vao: open_prev = opening N-1 (USD), so huu han > 0. Dau vao khong hop le -> thoat ma 2, khong bo qua am tham."""
import argparse, csv, json, math, sys

def load(path): return json.load(open(path, encoding='utf-8'))

def validate(v):
    try: x = float(v)
    except (TypeError, ValueError): raise ValueError(f'open_prev khong phai so: {v!r}')
    if not math.isfinite(x) or x <= 0: raise ValueError(f'open_prev phai huu han va > 0: {v!r}')
    return x

def predict(art, open_prev):
    x = validate(open_prev); lg = math.log(x)
    yh = art['intercept'] + art['coef_log_open_prev'] * lg
    med = art['baselines']['median_Y_dev']; rng = art['fit_input_range_open_prev']
    warn = '' if rng['min'] <= x <= rng['max'] else 'ngoai khoang open_prev cua tap fit (%.0f-%.0f)' % (rng['min'], rng['max'])
    pc = lambda y: 100.0 * (math.exp(y) - 1.0)
    return dict(open_prev=x, log_open_prev=lg, y_hat_E0=yh, pct_E0=pc(yh), y_hat_median=med, pct_median=pc(med), y_hat_Y0=0.0, pct_Y0=0.0, range_warning=warn)

def main():
    ap = argparse.ArgumentParser(); ap.add_argument('--artifact', default='e0_fitted.json'); ap.add_argument('--open-prev'); ap.add_argument('--input'); ap.add_argument('--output')
    ap.add_argument('--check'); ap.add_argument('--check-output'); ap.add_argument('--tol', type=float, default=1e-9)
    a = ap.parse_args(); art = load(a.artifact)
    try:
        if a.open_prev is not None:
            print(json.dumps(predict(art, a.open_prev), ensure_ascii=False, indent=1)); return 0
        if a.input:
            rows = list(csv.DictReader(open(a.input, encoding='utf-8'))); out = []
            for i, r in enumerate(rows, 2):
                if 'open_prev' not in r: raise ValueError('thieu cot open_prev')
                try: p = predict(art, r['open_prev'])
                except ValueError as e: raise ValueError(f'dong {i}: {e}')
                out.append({**({'transition_id': r['transition_id']} if 'transition_id' in r else {}), **p})
            if a.output:
                with open(a.output, 'w', newline='', encoding='utf-8') as f:
                    w = csv.DictWriter(f, fieldnames=list(out[0])); w.writeheader(); w.writerows(out)
            else: print(json.dumps(out, ensure_ascii=False, indent=1))
            return 0
        if a.check:
            rows = list(csv.DictReader(open(a.check, encoding='utf-8'))); res = []; ok = True
            for r in rows:
                p = predict(art, r['open_prev'])
                d = {'transition_id': r['transition_id'], 'diff_Y_E0': abs(p['y_hat_E0'] - float(r['Y_pred_E0'])), 'diff_pct_E0': abs(p['pct_E0'] - float(r['pct_pred_E0'])),
                     'diff_Y_median': abs(p['y_hat_median'] - float(r['Y_pred_median'])), 'diff_Y_Y0': abs(p['y_hat_Y0'] - float(r['Y_pred_Y0']))}
                res.append(d)
            mx = {k: max(d[k] for d in res) for k in ('diff_Y_E0', 'diff_pct_E0', 'diff_Y_median', 'diff_Y_Y0')}
            ok = all(v < a.tol for v in mx.values())
            if a.check_output:
                with open(a.check_output, 'w', newline='', encoding='utf-8') as f:
                    w = csv.writer(f); w.writerow(['n_rows', 'tolerance', *mx, 'status']); w.writerow([len(res), a.tol, *[f'{v:.3e}' for v in mx.values()], 'PASS' if ok else 'FAIL'])
            print(f'check: n={len(res)} max diffs={mx} -> {"PASS" if ok else "FAIL"}'); return 0 if ok else 1
        ap.error('can --open-prev, --input hoac --check')
    except ValueError as e:
        print('LOI DAU VAO:', e, file=sys.stderr); return 2
if __name__ == '__main__': sys.exit(main())
