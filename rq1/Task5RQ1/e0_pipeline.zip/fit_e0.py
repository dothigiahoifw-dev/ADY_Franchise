#!/usr/bin/env python3
"""Fit lai E0 chi tren 725 dong dev (data_dev/rq1_inputs_dev.csv), doi chieu hash nguon va he so voi e0_fitted.json.
Khong doc du lieu test. Dung: python fit_e0.py --artifact e0_fitted.json --data data_dev/rq1_inputs_dev.csv [--write e0_refit.json]"""
import argparse, csv, hashlib, json, math, statistics, sys
ap = argparse.ArgumentParser(); ap.add_argument('--artifact', default='e0_fitted.json'); ap.add_argument('--data', default='data_dev/rq1_inputs_dev.csv'); ap.add_argument('--write'); ap.add_argument('--tol', type=float, default=1e-9)
a = ap.parse_args(); art = json.load(open(a.artifact, encoding='utf-8'))
h = hashlib.sha256(open(a.data, 'rb').read()).hexdigest()
if h != art['source']['dev_inputs_sha256']: print('FAIL: hash du lieu dev khong khop artifact'); sys.exit(1)
rows = list(csv.DictReader(open(a.data, encoding='utf-8')))
if len(rows) != art['n_fit'] or any(r['role'] != 'dev' for r in rows): print('FAIL: so dong/role khong dung (can 725 dong dev)'); sys.exit(1)
x = [math.log(float(r['open_prev'])) for r in rows]; y = [float(r['Y']) for r in rows]
if not all(abs(xi - float(r['log_open_prev'])) < 1e-12 for xi, r in zip(x, rows)): print('FAIL: log_open_prev khong khop ln(open_prev)'); sys.exit(1)
xm, ym = math.fsum(x) / len(x), math.fsum(y) / len(y)
b = math.fsum((xi - xm) * (yi - ym) for xi, yi in zip(x, y)) / math.fsum((xi - xm) ** 2 for xi in x); c = ym - b * xm; med = statistics.median(y)
d = max(abs(c - art['intercept']), abs(b - art['coef_log_open_prev']), abs(med - art['baselines']['median_Y_dev']))
print(f'refit: intercept={c:.9f} slope={b:.9f} median_Y_dev={med:.9f} | max |diff| vs artifact = {d:.2e} -> {"PASS" if d < a.tol else "FAIL"}')
if a.write: json.dump({'intercept': c, 'coef_log_open_prev': b, 'median_Y_dev': med, 'n': len(rows)}, open(a.write, 'w'), indent=1)
sys.exit(0 if d < a.tol else 1)
