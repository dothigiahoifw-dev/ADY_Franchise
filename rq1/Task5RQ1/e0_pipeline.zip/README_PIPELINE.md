# Pipeline E0 đã fit — ADY_PRJ RQ1

**Đây là pipeline của cấu hình E0 đã khóa** (Linear Regression OLS, chỉ dùng `ln(open_prev)`), fit trên **725 dòng dev**. **Không phải phương án đã chứng minh vượt baseline:** trên 193 transition test, E0 chỉ nhỉnh hơn median Y của dev và Y=0 rất nhỏ (ΔMAE log +0,0020 và +0,0078), khoảng bootstrap 95% theo franchise chứa 0.

## File
| File | Vai trò |
|:--|:--|
| `e0_fitted.json` | Tham số đã fit: hệ số chặn, hệ số `log_open_prev`, thứ tự feature, công thức, số dòng fit, median Y của dev, khoảng `open_prev` của tập fit, hash nguồn |
| `predict_e0.py` | Dự báo (chỉ dùng thư viện chuẩn Python 3) |
| `fit_e0.py` | Fit lại từ `data_dev/rq1_inputs_dev.csv` (725 dòng dev; đối chiếu hash và hệ số) |
| `example_input.csv`, `example_output.csv` | Ví dụ đầu vào và đầu ra |
| `reference_predictions_task4.csv`, `artifact_check.csv` | Dự báo Task 4 trên 193 dòng test để kiểm tra artifact, và kết quả kiểm tra |

## Tham số đã fit
- Hệ số chặn: **1,338280**; hệ số `ln(open_prev)`: **−0,094323**; n fit = 725 dòng (449 franchise).
- Baseline: **median Y của dev = −0,163813** (tương ứng −15,11%); **Y=0** (0%).
- Công thức: Ŷ = 1,338280 − 0,094323 × ln(open_prev); thay đổi dự báo (%) = 100 × (exp(Ŷ) − 1).

## Cách chạy
```
python predict_e0.py --artifact e0_fitted.json --open-prev 20000000
python predict_e0.py --artifact e0_fitted.json --input example_input.csv --output example_output.csv
python predict_e0.py --artifact e0_fitted.json --check reference_predictions_task4.csv --check-output artifact_check.csv
python fit_e0.py --artifact e0_fitted.json --data data_dev/rq1_inputs_dev.csv
```
**Ví dụ.** `open_prev = 20.000.000` → `log_open_prev = 16,8112`, Ŷ(E0) = −0,2474 → **−21,9%**; median baseline Ŷ = −0,1638 → −15,1%; Y=0 → 0%.

## Kiểm tra đầu vào
`open_prev` là opening N−1 (USD, theo quy ước đo của dữ liệu dự án), phải là số **hữu hạn và > 0**. Giá trị `0`, âm, chữ, `nan`, `inf` hoặc rỗng bị từ chối (mã thoát 2, không bỏ qua âm thầm). Ngoài khoảng `open_prev` của tập fit (576 đến 260.138.569 USD) script chỉ **cảnh báo** (`range_warning`), không chặn.

## Giới hạn sử dụng
- Mô hình chỉ biết opening N−1; không biết marketing, chất lượng phim, đối thủ cùng tuần hay các thông tin riêng của phim.
- Dự báo nằm trong khoảng hẹp (trên test: −0,49 đến 0,65 log-change, tức −38,6% đến +90,8%) trong khi Y thực tế trải từ −10,4 đến 6,6; sai số tuyệt đối trung vị trên test khoảng 41 điểm phần trăm.
- Đánh giá trên **franchise chưa thấy có ghi nhận opening**, chưa kiểm tra theo thời gian. Nhóm `open_prev` < 1 triệu có sai số lớn hơn (n test = 38).
- Opening phải cùng quy ước đo với dữ liệu dự án (thị trường, tiền tệ, cửa sổ chưa được xác minh); hệ số là liên hệ dự báo, không phải quan hệ nhân quả.
- Kiểm tra artifact (`artifact_check.csv`) chỉ xác nhận script tái tạo dự báo Task 4, không phải vòng đánh giá mới.
