# RQ1 — Dự báo phần trăm thay đổi opening giữa hai phần liên tiếp: báo cáo gửi nhóm

**Dự án:** ADY_PRJ — Franchise Sequel Revenue Decay · **Người phụ trách RQ1:** trực tiếp
**Căn cứ:** các gói Task 2 (mẫu, feature, split), Task 3 (chọn cấu hình trên dev), Task 4 (chấm test). Mọi số liệu trong báo cáo này đã được tính lại từ các bảng dự báo theo `transition_id` (28/28 kiểm tra trong `logs/verification_report.csv` PASS).

## Kết luận RQ1 (dán được vào báo cáo nhóm)

> Trên 193 transition test (113 franchise chưa xuất hiện trong huấn luyện), mô hình hồi quy tuyến tính E0 chỉ dùng ln(opening phần trước) có MAE log là **0,880**, thấp hơn nhẹ median Y của tập dev (0,882; ΔMAE = +0,0020) và dự báo "không đổi" Y = 0 (0,888; ΔMAE = +0,0078). Sai số tuyệt đối trung vị của dự báo phần trăm thay đổi khoảng **41 điểm phần trăm**. Cả hai khoảng bootstrap 95% theo franchise ([−0,039; +0,042] và [−0,032; +0,049]) chứa 0, và thứ hạng trên test ngược với trên dev (nơi median dẫn đầu), nên dữ liệu hiện có **chưa chứng minh E0 dự báo tốt hơn baseline đơn giản**. Kết luận chỉ áp dụng cho franchise chưa thấy có ghi nhận opening (3,5% transition hợp lệ), chưa được kiểm tra theo thời gian, và phụ thuộc vào quy ước collection và tính so sánh của opening chưa được xác minh; mức chắc chắn của kết luận là **thấp**.

## A. Câu hỏi, căn cứ và ý nghĩa business

**RQ1.** Có thể dự đoán phần trăm thay đổi doanh thu cuối tuần mở màn từ phần N−1 sang phần N không?

**Target cố định:** Y = ln(Open_N) − ln(Open_N−1). Dự báo Ŷ được quy đổi thành phần trăm thay đổi bằng 100 × (exp(Ŷ) − 1). Ví dụ Ŷ = −0,247 tương ứng −21,9%.

**Vì sao cần baseline.** Một mô hình chỉ có giá trị khi dự báo tốt hơn cách làm không cần mô hình. Có hai cách như vậy: (1) **Y = 0**, giả định opening không đổi so với phần trước; (2) **median Y của dev**, giả định phần sau thay đổi bằng mức trung vị lịch sử (−0,164 ≈ **−15,1%**). Nếu mô hình không hơn rõ ràng hai cách này, việc đưa thêm mô hình vào quy trình ra quyết định chưa tạo thêm giá trị. Vì vậy báo cáo luôn trình bày kết quả của ba phương án cạnh nhau, và đánh giá trên tập test giữ lại để tránh chọn theo kết quả.

**Ý nghĩa business.** Kết quả cho biết, từ chỉ một thông tin có sẵn trước phần N (opening phần trước), có thể dự báo bao nhiêu về mức thay đổi opening, và sai số điển hình khi áp dụng cho franchise mới. Đây là cơ sở để người dùng quyết định có nên dựa vào dự báo kiểu này hay không, chứ không phải lời khuyên sản xuất hay đầu tư.

## B. Mẫu, split và cách chọn cấu hình

**Đơn vị.** Một dòng là một cặp phần liên tiếp trong cùng franchise (TMDB collection; quy ước này chưa được xác minh). Chi tiết: `SAMPLE_AND_SPLIT.md`.

| Bước | Transition | Franchise |
|:--|--:|--:|
| Cặp ứng viên | 30.113 | 9.718 |
| Hợp lệ kỹ thuật | 25.943 | 8.731 |
| **Có opening cả hai phim (mẫu có nhãn)** | **918** | **562** |

- **Các cặp thiếu opening được giữ trong danh sách kiểm kê** (thiếu cả hai 24.209; chỉ thiếu N 574; chỉ thiếu N−1 242). Không điền median vào opening để tạo nhãn. Độ phủ 918/25.943 ≈ **3,5%**.
- **Split theo franchise:** dev **725 dòng / 449 franchise** (bốn fold: 178/185/176/186 dòng), test **193 dòng / 113 franchise**; không franchise nào nằm ở hai tập.
- **Ngưỡng opening N−1 ≥ 1 triệu USD chỉ dùng để phân tầng báo cáo**, không loại dòng khỏi mẫu chính (dev: 576 / 149 dòng; test: 155 / 38).
- **Chọn cấu hình trên dev (ngoài fold 4 lần).** Năm cấu hình E0–E4 được so với quy tắc đã chốt: một cấu hình chỉ thay E0 nếu MAE gộp thấp hơn E0 và thấp hơn ở ít nhất 3/4 fold. E1–E4 đều có MAE gộp cao hơn E0 (E1 +0,0071; E2 +0,0001; E3 +0,0032; E4 +0,0058 so với E0), nên **không cấu hình nào đạt và E0 được giữ**. E0 chỉ dùng `log_open_prev` (một hệ số chặn và một hệ số dốc).
- **Cần hiểu đúng:** E0 là cấu hình hồi quy được khóa, **không phải mô hình tốt nhất trên dev**. Trên dev, **median Y có MAE thấp nhất** (0,8124 so với 0,8218 của Y=0 và 0,8253 của E0). Quy tắc chọn chỉ so các cấu hình hồi quy với nhau; so với baseline là bước riêng.

| Dev, ngoài fold (725 dòng) | MAE log | RMSE log | Thấp hơn E0 ở số fold |
|:--|:--:|:--:|:--:|
| Median Y của dev | **0,8124** | 1,3023 | — |
| Y=0 | 0,8218 | 1,3087 | — |
| **E0** | 0,8253 | 1,2844 | — |
| E1 (+ln gap) | 0,8324 | 1,2881 | 3/4 |
| E2 (+ln vị trí phần) | 0,8254 | **1,2797** | 2/4 |
| E3 (+tháng, năm chiếu) | 0,8285 | 1,2896 | 2/4 |
| E4 (đủ 5 feature) | 0,8311 | 1,2869 | 1/4 |

*E1–E4 không được chấm trên test.* Thông tin về cách chọn: `tables/dev_selection_table.csv`.

## C. Kết quả trên test và so sánh với baseline

Test là tập giữ lại, chấm một lần. Cả ba phương án được fit trên toàn bộ 725 dòng dev (E0: Ŷ = 1,33828 − 0,09432 × ln(open_prev); median Y = −0,16381; Y=0) rồi dự báo 193 dòng test. Sai số điểm phần trăm = |100(exp(Y) − 1) − 100(exp(Ŷ) − 1)| (đổi từng giá trị trước khi lấy chênh lệch).

| Phương án | MAE log dev (ngoài fold) | **MAE log test** | RMSE log test | MAE log TB theo franchise (test) | Sai số điểm % trung vị (test) |
|:--|:--:|:--:|:--:|:--:|:--:|
| Y=0 | 0,8218 | 0,8879 | 1,5026 | 0,9662 | 48,44 |
| Median Y của dev | 0,8124 | 0,8821 | 1,4927 | 0,9486 | **40,63** |
| **E0** | 0,8253 | **0,8801** | **1,4688** | **0,9233** | 40,66 |

**ΔMAE = MAE_baseline − MAE_E0** (dương: E0 sai số thấp hơn):

| So với | Tầng | n | ΔMAE | Khoảng bootstrap 95% theo franchise (bổ trợ) | % franchise E0 thấp hơn |
|:--|:--|:--:|:--:|:--:|:--:|
| Median | Tất cả | 193 | **+0,0020** | [−0,0386; +0,0422] | 59,3% |
| Y=0 | Tất cả | 193 | **+0,0078** | [−0,0322; +0,0486] | 61,1% |

**Đọc kết quả:**
- **E0 có MAE log thấp nhất trên tập test này**, đồng thời có RMSE log và MAE trung bình theo franchise thấp nhất. Theo sai số điểm phần trăm trung vị, E0 (40,66) và median (40,63) gần như bằng nhau; cả hai tốt hơn Y=0 (48,44).
- **Mức chênh rất nhỏ** (0,002 và 0,008 log) so với biến động giữa các fold trên dev (độ lệch chuẩn MAE giữa fold khoảng 0,09–0,12) và so với độ rộng khoảng bootstrap (khoảng ±0,04). **Cả hai khoảng chứa 0.**
- **Thứ hạng đảo so với dev**: trên dev median dẫn đầu và E0 thấp nhất (ΔMAE −0,0129 so với median và −0,0035 so với Y=0); trên test E0 nhỉnh hơn. MAE test của cả ba phương án đều cao hơn MAE dev ngoài fold khoảng 0,055–0,070; hai con số dùng giao thức khác nhau (dev: ngoài fold bốn lần; test: fit trên 725 dòng, giữ lại 193 dòng) nên không so như cùng một thước.
- **Độ nhạy của ΔMAE với từng dòng.** Đóng góp của một dòng đơn lẻ vào ΔMAE so với median có thể lên tới ±0,0042 (gấp khoảng 2 lần chính ΔMAE +0,0020); dòng lớn nhất là `FK00041922__FK00073252` (có cờ chất lượng) và `FK00015137__FK00022843` (`tables/delta_mae_top_row_contributions.csv`). Chiều của ΔMAE so với median vì vậy không ổn định.
- **Cách đọc sai số.** MAE log là sai số tuyệt đối trung bình trên thang log; không đổi trực tiếp sang phần trăm. Trên thang phần trăm, sai số tuyệt đối trung vị của E0 khoảng **40,7 điểm phần trăm**: một nửa số dự báo lệch ít hơn mức này, nửa còn lại lệch nhiều hơn. Trung bình sai số điểm phần trăm (≈ 553 điểm phần trăm cho cả ba phương án) bị vài giá trị cực trị chi phối, vì Y lớn (đến 6,6) tương ứng thay đổi hàng chục nghìn phần trăm, nên không dùng để so sánh.

## D. Phân tích lỗi và độ vững

### D1. Theo tầng opening N−1 (test)

| Tầng | n (franchise) | Phương án | MAE log | Sai số điểm % trung vị |
|:--|:--:|:--|:--:|:--:|
| `open_prev` ≥ 1M | 155 (87) | Y=0 | 0,7540 | 41,16 |
| | | Median | **0,7395** | 36,63 |
| | | E0 | 0,7442 | **33,94** |
| `open_prev` < 1M | **38** (29) | Y=0 | **1,4341** | 74,84 |
| | | Median | 1,4641 | **62,58** |
| | | E0 | 1,4347 | 120,47 |

- Ở tầng ≥ 1M, E0 kém median 0,0047 theo MAE log nhưng tốt hơn Y=0 0,0098; tầng này cùng chiều với dev.
- **Tầng < 1M chỉ có 38 dòng (29 franchise)**: sai số cao hơn rõ (MAE log khoảng 1,43–1,46), khoảng bootstrap rất rộng (ví dụ ΔMAE E0 so với median +0,0295, khoảng [−0,154; +0,220]), nên **không đủ cơ sở kết luận** gì về E0 ở tầng này; ở tầng này sai số điểm phần trăm trung vị của E0 (120) cao hơn median (63).

### D2. S1 và S2 (chỉ chạy trên dev)

S1/S2 được chạy và tái lập ở Task 3 trên **dev**, không chạy trên test (để không tạo thêm lần thử trên test). Hiệu lực chỉ trong phạm vi dev.

| Phép thử (dev) | Phạm vi | Median | E0 chính | E0 biến thể |
|:--|:--|:--:|:--:|:--:|
| S1: bỏ 6 dòng có cờ khỏi tập fit | 719 dòng không cờ | 0,7966 → 0,7968 | 0,8077 | 0,8057 |
| S2: chỉ fit trên nhóm ≥ 1M | 725 dòng | 0,8124 → 0,8126 | 0,8253 | 0,8401 |
| | ≥ 1M (576) | 0,6534 → 0,6529 | 0,6642 | 0,6591 |
| | < 1M (149) | 1,4271 → 1,4298 | 1,4480 | 1,5401 |

Cả hai không đổi kết luận "median dẫn đầu trên dev". Riêng S2 làm E0 kém hơn ở nhóm < 1M vì dự báo ngoài miền huấn luyện. Chưa biết kết quả test có nhạy với các điều kiện này hay không.

### D3. Dòng có sai số lớn (test)

| Nhóm | n | % số dòng | % tổng sai số tuyệt đối của E0 |
|:--|:--:|:--:|:--:|
| 4 dòng có cờ chất lượng opening | 4 | 2,1% | 9,9% |
| 12 dòng \|Y\| > 3 | 12 | 6,2% | 31,8% |
| 11 dòng `open_prev` ≥ 1M nhưng `open_curr` < 1M | 11 | 5,7% | 23,3% |
| 15 dòng sai số lớn nhất | 15 | 7,8% | 36,4% |

Ví dụ: `FK00010065__FK00203835` có `open_prev` ≈ 23,5 triệu, `open_curr` = 742, Y ≈ −10,36, chiếm 5,9% tổng sai số của E0 (sai số log 10,10; median 10,20; Y=0 10,36). `FK00016780__FK00076617` có `open_prev` = 28.235, `open_curr` ≈ 21,7 triệu, Y ≈ +6,65. Các dòng này chỉ là **quan sát có sai số lớn**; một số mang cờ chất lượng nhưng cờ chỉ là cảnh báo. **Chưa có dòng nào được xác minh là lỗi nguồn**; cần đối chiếu định nghĩa nguồn (thị trường, cửa sổ chiếu, tính so sánh opening). Tất cả dòng đều giữ trong bảng điểm chính. Cả ba phương án đều sai lớn ở các dòng này, nghĩa là mô hình không bù trừ được chúng.

## E. Ý nghĩa business, giới hạn và câu trả lời RQ1

**Mô hình đưa ra dự báo định lượng, nhưng lợi thế so với baseline chưa ổn định.** Với opening N−1 = 20 triệu USD, E0 dự báo Ŷ = −0,247 (−21,9%), median baseline −15,1%, Y=0 là 0%. Hệ số dốc −0,094 cho thấy opening N−1 càng cao thì mức thay đổi dự báo càng thấp (mỗi lần opening N−1 gấp đôi, Ŷ thấp hơn khoảng 0,065); đây là liên hệ dự báo, không phải quan hệ nhân quả, và có thể phản ánh hiệu ứng hồi quy về trung bình vì `log_open_prev` có mặt trong Y. Dự báo của E0 chỉ trải trong khoảng −0,49 đến 0,65 (−38,6% đến +90,8%) trên test, trong khi Y thực tế trải từ −10,4 đến 6,6.

**Phạm vi áp dụng.** Franchise chưa xuất hiện trong huấn luyện **và có ghi nhận opening**; độ phủ opening khoảng 3,5% trong các transition hợp lệ kỹ thuật, gần 0% trước 1980 và 3–6% sau đó.

**Giới hạn.**
1. **Quy ước collection (A1):** franchise là TMDB collection; việc hai phim cùng collection là hai phần liên tiếp chưa được xác minh.
2. **Tính so sánh opening (A2):** thị trường, tiền tệ, cửa sổ và số rạp của opening chưa được xác minh; các cực trị chưa phân biệt được là dự báo đúng hay lỗi so sánh.
3. **Split theo franchise, không theo thời gian:** năm chiếu dev và test chồng lấn; kết quả không chứng minh khả năng dự báo phim phát hành trong tương lai.
4. **Cỡ test:** 193 dòng, 113 franchise; tầng < 1M chỉ 38 dòng; bootstrap chỉ phản ánh biến động theo thành phần franchise, không tính bất định của bước fit trên dev.
5. **Mô hình đơn giản:** chỉ opening N−1; E1–E4 (thêm gap, vị trí phần, mùa, năm) không cải thiện trên dev; các nhóm đạo diễn/công ty/thể loại (E5–E7) chưa chạy do chưa xác nhận điều kiện sử dụng. Chưa có cơ sở để kết luận nguyên nhân của việc không cải thiện.
6. **Phát triển trên dev có phần thiên lệch nhẹ:** phần dư của E4 đã được xem một lần (không đổi gì); không hiệu chỉnh cho việc so sánh năm cấu hình.
7. **Giới hạn kỹ thuật Task 3:** nhánh đổi biểu diễn đọc `rep_decision.json` nhưng vẫn gán `REP = {}`; không được kích hoạt trong lần chạy đã khóa (0 thay đổi), nên kết quả không bị ảnh hưởng.

**Đính chính so với báo cáo Task 4.** (1) Báo cáo Task 4 diễn giải MAE log 0,88 là "sai lệch điển hình gần gấp 2,4 lần"; cách nói đó **không đúng** (exp(MAE log) không phải sai lệch điển hình) và đã bỏ; dùng sai số điểm phần trăm trung vị (≈ 41) thay thế. (2) Báo cáo Task 4 viết ΔMAE "nhỏ hơn nhiều" so với tác động của vài dòng cực trị; số đã kiểm tra là đóng góp một dòng tới 0,0042, **gấp khoảng 2 lần** ΔMAE (+0,0020). Số liệu bảng không đổi.

**Hướng tiếp theo (không làm trong báo cáo này).** Xác minh quy ước collection và tính so sánh opening; đánh giá theo thời gian; xem xét các cực trị theo `transition_id`; chạy nhóm hồi cứu E5–E7 sau khi xác nhận điều kiện sử dụng. Không có thay đổi nào được áp dụng lên kết quả test đã chốt.

## Phụ lục — File liên quan
Bảng: `tables/` (`main_results_table.csv`, `test_metrics.csv`, `test_paired_comparison.csv`, `test_predictions_by_transition.csv`, `dev_selection_table.csv`, `test_error_by_stratum.csv`, `s1_s2_dev_summary.csv`, `test_top_errors.csv`, `test_influential_summary.csv`, `dev_test_composition.csv`, `sample_funnel.csv`, `split_summary.csv`, `split_assignment.csv`). Hình: `figures/fig1_test_mae.png` (MAE test của ba phương án, kèm MAE dev), `fig2_delta_mae.png` (ΔMAE và khoảng bootstrap), `fig3_test_actual_vs_pred.png` (Y thực tế và dự báo trên test), `fig4_s1_s2_dev.png` (S1/S2 trên dev). Pipeline: `pipeline/`. Kiểm tra: `logs/verification_report.csv`.
