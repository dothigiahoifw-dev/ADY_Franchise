# ADY_PRJ RQ1 — Task 5 (Bước 8): báo cáo nhóm và bàn giao

## Đọc theo thứ tự
1. `TASK5_RQ1_GROUP_REPORT.md` — báo cáo độc lập gửi nhóm (có đoạn kết luận dán được).
2. `SAMPLE_AND_SPLIT.md` — tài liệu mẫu và split.
3. `tables/` — bảng; `figures/` — 4 biểu đồ PNG và CSV tạo hình.
4. `pipeline/` — **pipeline E0 đã fit** (dùng độc lập; xem `pipeline/README_PIPELINE.md`).
5. `logs/verification_report.csv` — 28 kiểm tra đối chiếu (PASS); `reference/` — cấu hình khóa, bản ghi trước chấm, hash gói nguồn; `manifest_task5.csv` — hash mọi file.

## Dự báo nhanh
```
cd pipeline
python predict_e0.py --artifact e0_fitted.json --open-prev 20000000     # → Ŷ = −0,2474 (−21,9%); median −15,1%; Y=0 0%
python predict_e0.py --artifact e0_fitted.json --check reference_predictions_task4.csv --check-output artifact_check.csv
python fit_e0.py --artifact e0_fitted.json --data data_dev/rq1_inputs_dev.csv
```
Đầu vào `open_prev` phải hữu hạn và > 0 (giá trị khác bị từ chối, mã thoát 2). Yêu cầu: Python 3 (chỉ thư viện chuẩn).

## Tái tạo gói (từ ba gói nguồn)
`python code/t5_build.py --t2 <task2_rq1> --t3 <task3_rq1> --t4 <task4_rq1> --out .` (cần numpy, pandas, matplotlib; dừng nếu bất kỳ kiểm tra nào FAIL). `python code/t5_manifest.py .` tạo manifest; thêm `--verify` để kiểm tra.

## Lưu ý
- Task 5 không mở file test (chỉ hash byte để đối chiếu bản ghi Task 4), không chấm thêm mô hình, không đổi mẫu hay metric.
- `task2(1).zip` không có mặt trong phiên; dùng `task2_rq1.zip`, hash của mọi file trong gói khớp `locked_config_rq1.json`.
- E0 là **pipeline của cấu hình đã khóa, không phải phương án đã chứng minh vượt baseline.**
