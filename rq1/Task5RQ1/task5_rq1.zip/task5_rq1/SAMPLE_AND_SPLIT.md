# Mẫu và split — RQ1

**Đơn vị:** một transition N−1 → N giữa hai phần liên tiếp trong cùng TMDB collection (quy ước franchise chưa xác minh, A1). **Target:** Y = ln(Open_N) − ln(Open_N−1).

## Phễu mẫu (`tables/sample_funnel.csv`, `tables/coverage_exclusions_summary.csv`)
| Bước | Transition | Franchise | Loại |
|:--|--:|--:|--:|
| Cặp ứng viên trong `pairs_audit` | 30.113 | 9.718 | — |
| Hợp lệ kỹ thuật (cùng collection, kế tiếp, ngày hợp lệ, không trùng ngày, đã phát hành) | 25.943 | 8.731 | 4.170 |
| Có opening cả N−1 và N (mẫu có nhãn) | **918** | **562** | 25.025 |

Các cặp thiếu opening **không bị xóa khỏi kiểm kê**: chúng nằm trong danh sách loại trừ của Task 2 với lý do (thiếu cả hai 24.209; chỉ thiếu N 574; chỉ thiếu N−1 242). **Không điền median hay giá trị khác vào opening để tạo nhãn.** Độ phủ opening: 918/25.943 = **3,5%**.

## Split (`tables/split_assignment.csv`, `tables/split_summary.csv`)
| | Transition | Franchise | `open_prev` ≥ 1M | `open_prev` < 1M |
|:--|--:|--:|--:|--:|
| Dev | 725 | 449 | 576 (342 fr.) | 149 (120 fr.) |
| Test | 193 | 113 | 155 (87 fr.) | 38 (29 fr.) |

Dev có bốn fold (178/185/176/186 dòng; 113/112/112/112 franchise). Chia **theo franchise**: không franchise nào ở hai tập hay hai fold. Ngưỡng 1 triệu chỉ dùng để phân tầng báo cáo; không dòng nào bị loại vì ngưỡng. Split này đo khả năng tổng quát hóa sang **franchise chưa thấy**, không phải kiểm định theo thời gian.
