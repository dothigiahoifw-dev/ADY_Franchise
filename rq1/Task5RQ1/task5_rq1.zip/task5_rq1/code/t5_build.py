#!/usr/bin/env python3
"""RQ1 Task 5 (Buoc 8): doi chieu so lieu, fit artifact E0 (chi 725 dong dev), bang, hinh, goi pipeline.
Khong mo file test (chi dung bang du bao Task 4). Khong chon lai mo hinh. FAIL -> dung.
python t5_build.py --t2 <task2_rq1> --t3 <task3_rq1> --t4 <task4_rq1> --out <task5_rq1>"""
import argparse, json, os, shutil, subprocess, sys, platform, math
import numpy as np, pandas as pd
import matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt

ap = argparse.ArgumentParser()
for k in ('t2', 't3', 't4', 'out'): ap.add_argument(f'--{k}', required=True)
a = ap.parse_args(); T2, T3, T4, OUT = a.t2, a.t3, a.t4, a.out
TB, FG, PL, LG, RF = (f'{OUT}/{d}' for d in ('tables', 'figures', 'pipeline', 'logs', 'reference'))
def sha(p):
    import hashlib; h = hashlib.sha256(); h.update(open(p, 'rb').read()); return h.hexdigest()
def pct(v): return 100.0 * (np.exp(v) - 1.0)
V = []
def chk(cid, desc, expected, actual, ok):
    V.append(dict(id=cid, description=desc, expected=str(expected), actual=str(actual), status='PASS' if bool(ok) else 'FAIL'))
def stop_if_fail():
    t = pd.DataFrame(V); t.to_csv(f'{LG}/verification_report.csv', index=False)
    if (t.status == 'FAIL').any():
        print(t[t.status == 'FAIL'].to_string(index=False)); print('*** FAIL: dung, khong tao goi. ***'); sys.exit(1)

# ---------- 1. Hash va manifest ----------
lock = json.load(open(f'{T3}/locked_config_rq1.json'))
for nm, root, mf in (('Task 3', T3, 'manifest_task3.csv'), ('Task 4', T4, 'manifest_task4.csv')):
    m = pd.read_csv(f'{root}/{mf}'); bad = [r.file for r in m.itertuples() if not os.path.exists(f'{root}/{r.file}') or sha(f'{root}/{r.file}') != r.sha256]
    chk(f'H_{nm}', f'manifest {nm}: moi file khop hash', f'{len(m)} file', f'bad={bad}', not bad)
m2 = pd.read_csv(f'{T2}/manifest_outputs.csv'); bad = [r.file for r in m2.itertuples() if sha(f'{T2}/{r.file}') != r.sha256]
chk('H_Task2', 'manifest_outputs Task 2: moi file khop hash', f'{len(m2)} file', f'bad={bad}', not bad)
li = lock['inputs']
chk('H_lock_dev', 'hash dev inputs Task 2 == locked_config Task 3', li['rq1_inputs_dev.csv'][:12], sha(f'{T2}/data/rq1_inputs_dev.csv')[:12], sha(f'{T2}/data/rq1_inputs_dev.csv') == li['rq1_inputs_dev.csv'])
chk('H_lock_split', 'hash split == locked_config', lock['split']['sha256'][:12], sha(f'{T2}/data/split_assignment.csv')[:12], sha(f'{T2}/data/split_assignment.csv') == lock['split']['sha256'])
pre = json.load(open(f'{T4}/records/prescore_record.json'))
chk('H_prescore', 'prescore_record Task 4: hash khop file .sha256', '', sha(f'{T4}/records/prescore_record.json')[:12], sha(f'{T4}/records/prescore_record.json') == open(f'{T4}/records/prescore_record.sha256').read().strip())
chk('H_test_bytes', 'hash byte file test == ban ghi truoc cham Task 4 (chi hash, khong doc noi dung)', pre['hashes_actual']['test_bytes'][:12], sha(f'{T2}/data/rq1_inputs_test_LOCKED.csv')[:12], sha(f'{T2}/data/rq1_inputs_test_LOCKED.csv') == pre['hashes_actual']['test_bytes'])
stop_if_fail()

# ---------- 2. Doi chieu so lieu theo transition_id ----------
P = pd.read_csv(f'{T4}/results/test_predictions_by_transition.csv'); TM = pd.read_csv(f'{T4}/results/test_metrics.csv'); PC = pd.read_csv(f'{T4}/results/test_paired_comparison.csv')
SP = pd.read_csv(f'{T2}/data/split_assignment.csv')
chk('N01', 'bang du bao test: 193 dong, ID duy nhat, trung tap test cua split', 193, len(P), len(P) == 193 and P.transition_id.is_unique and set(P.transition_id) == set(SP[SP.role != 'dev'].transition_id))
chk('N02', 'Y_true == ln(open_curr) - ln(open_prev) (1e-12)', '<1e-12', float(np.abs(P.Y_true - (np.log(P.open_curr) - np.log(P.open_prev))).max()), np.abs(P.Y_true - (np.log(P.open_curr) - np.log(P.open_prev))).max() < 1e-12)
mods = ['Y0', 'median', 'E0']; ae = {m: np.abs(P.Y_true.values - P[f'Y_pred_{m}'].values) for m in mods}
pe = {m: np.abs(pct(P.Y_true.values) - pct(P[f'Y_pred_{m}'].values)) for m in mods}
chk('N03', 'sai so log va diem % trong bang khop tinh lai tu Y_true, Y_pred (1e-9)', '<1e-9', max(float(np.abs(ae[m] - P[f'abs_err_log_{m}']).max()) for m in mods) , all(np.abs(ae[m] - P[f'abs_err_log_{m}']).max() < 1e-9 and np.abs(pe[m] - P[f'abs_err_pp_{m}']).max() < 1e-6 for m in mods))
exp = {'E0': 0.8801, 'median': 0.8821, 'Y0': 0.8879}
for m in mods: chk(f'N04_{m}', f'MAE log test {m}: tinh lai tu bang du bao == so trong yeu cau (4 chu so)', exp[m], round(float(ae[m].mean()), 4), round(float(ae[m].mean()), 4) == exp[m] and abs(ae[m].mean() - TM[(TM.model == m) & (TM.scope == 'tat ca')].mae_log.iloc[0]) < 1e-12)
chk('N05', 'delta MAE tinh lai: +0.0020 (median), +0.0078 (Y0)', '(0.0020, 0.0078)', (round(float(ae['median'].mean() - ae['E0'].mean()), 4), round(float(ae['Y0'].mean() - ae['E0'].mean()), 4)), round(float(ae['median'].mean() - ae['E0'].mean()), 4) == 0.0020 and round(float(ae['Y0'].mean() - ae['E0'].mean()), 4) == 0.0078)
chk('N06', 'sai so diem % trung vi E0 = 40.7 (lam tron 1 chu so)', 40.7, round(float(np.median(pe['E0'])), 1), round(float(np.median(pe['E0'])), 1) == 40.7)
# tai lap bootstrap (cung seed, cung thu tu rng)
rng = np.random.default_rng(20261107); frs = P.franchise_id.values
strat = {'tat ca': np.ones(len(P), bool), 'open_prev >=1M': P.mau_chinh.values, 'open_prev <1M': ~P.mau_chinh.values}
bt = []
for ref in ('median', 'Y0'):
    for sn, mk in strat.items():
        d = (ae[ref] - ae['E0'])[mk]; f_mk = frs[mk]; ufm = np.unique(f_mk); n_f = np.array([(f_mk == f).sum() for f in ufm]); s_f = np.array([d[f_mk == f].sum() for f in ufm])
        draws = rng.integers(0, len(ufm), size=(10000, len(ufm))); bs = s_f[draws].sum(1) / n_f[draws].sum(1)
        bt.append((ref, sn, d.mean(), np.percentile(bs, 2.5), np.percentile(bs, 97.5)))
bt = pd.DataFrame(bt, columns=['reference', 'scope', 'dm', 'lo', 'hi']).merge(PC, on=['reference', 'scope'])
chk('N07', 'ΔMAE va khoang bootstrap 95% tai lap khop bang Task 4 (1e-12)', '<1e-12', float(max((bt.dm - bt.delta_MAE).abs().max(), (bt.lo - bt.boot_ci95_low).abs().max(), (bt.hi - bt.boot_ci95_high).abs().max())), max((bt.dm - bt.delta_MAE).abs().max(), (bt.lo - bt.boot_ci95_low).abs().max(), (bt.hi - bt.boot_ci95_high).abs().max()) < 1e-12)
oof = pd.read_csv(f'{T3}/results/oof_predictions_wide.csv'); dm_ = {m: float(np.abs(oof.Y - oof[f'pred_{m}']).mean()) for m in mods}
chk('N08', 'MAE log dev ngoai fold tinh lai tu OOF Task 3: E0 0.8253, median 0.8124, Y0 0.8218', '(0.8253, 0.8124, 0.8218)', tuple(round(dm_[m], 4) for m in ('E0', 'median', 'Y0')), [round(dm_[m], 4) for m in ('E0', 'median', 'Y0')] == [0.8253, 0.8124, 0.8218])
# anh huong tung dong len delta MAE
contrib = P[['transition_id', 'franchise_id', 'mau_chinh', 'quality_flag_any', 'open_prev', 'open_curr', 'Y_true', 'Y_pred_E0']].copy()
contrib['contrib_delta_vs_median'] = (ae['median'] - ae['E0']) / len(P); contrib['contrib_delta_vs_Y0'] = (ae['Y0'] - ae['E0']) / len(P)
ct = contrib.reindex(contrib.contrib_delta_vs_median.abs().sort_values(ascending=False).index).head(10); ct.to_csv(f'{TB}/delta_mae_top_row_contributions.csv', index=False)
chk('N09', 'tong dong gop tung dong == ΔMAE', '', float(contrib.contrib_delta_vs_median.sum() - (ae['median'].mean() - ae['E0'].mean())), abs(contrib.contrib_delta_vs_median.sum() - (ae['median'].mean() - ae['E0'].mean())) < 1e-12)
stop_if_fail()

# ---------- 3. Fit lai E0 chi tren 725 dong dev ----------
dev = pd.read_csv(f'{T2}/data/rq1_inputs_dev.csv')
chk('F01', 'dau vao dev: 725 dong, role=dev, ID duy nhat, open_prev > 0', 725, len(dev), len(dev) == 725 and (dev.role == 'dev').all() and dev.transition_id.is_unique and (dev.open_prev > 0).all())
x = dev.log_open_prev.values.astype(float); y = dev.Y.values.astype(float)
chk('F02', 'log_open_prev == ln(open_prev) (1e-12)', '<1e-12', float(np.abs(x - np.log(dev.open_prev)).max()), np.abs(x - np.log(dev.open_prev)).max() < 1e-12)
xm, ym = math.fsum(x) / len(x), math.fsum(y) / len(y)
slope = math.fsum((xi - xm) * (yi - ym) for xi, yi in zip(x, y)) / math.fsum((xi - xm) ** 2 for xi in x); icpt = ym - slope * xm
med = float(np.median(y)); t4p = json.load(open(f'{T4}/results/dev_fit_parameters.json'))
d_ = max(abs(icpt - t4p['E0_intercept']), abs(slope - t4p['E0_slope_log_open_prev']), abs(med - t4p['median_Y_dev']))
chk('F03', 'he so E0 va median fit tren 725 dong dev khop Task 4 (1e-9)', f"{t4p['E0_intercept']:.9f}, {t4p['E0_slope_log_open_prev']:.9f}, {t4p['median_Y_dev']:.9f}", f'{icpt:.9f}, {slope:.9f}, {med:.9f}', d_ < 1e-9)
stop_if_fail()

# ---------- 4. Artifact E0 va goi pipeline ----------
art = {
 'artifact': 'e0_fitted', 'status': 'Pipeline cua cau hinh E0 da khoa (RQ1). KHONG phai phuong an da chung minh vuot baseline: tren test E0 chi nhinh hon median/Y=0 rat nho, khoang bootstrap chua 0.',
 'target': 'Y = ln(Open_N) - ln(Open_N-1)', 'prediction': {'y_hat': 'intercept + coef_log_open_prev * ln(open_prev)', 'pct_change': '100 * (exp(y_hat) - 1)'},
 'model': 'Linear Regression OLS co he so chan', 'feature_order': ['log_open_prev'], 'feature_transform': {'log_open_prev': 'ln(open_prev), open_prev = opening weekend gross cua N-1 (USD, theo quy uoc do cua du lieu du an)'},
 'intercept': icpt, 'coef_log_open_prev': slope, 'n_fit': int(len(dev)), 'n_franchises_fit': int(dev.franchise_id.nunique()),
 'baselines': {'median_Y_dev': med, 'median_pct_change': float(pct(med)), 'Y0': 0.0, 'Y0_rule': 'du bao hang so Y_hat = 0 (0% thay doi)'},
 'fit_input_range_open_prev': {'min': float(dev.open_prev.min()), 'max': float(dev.open_prev.max()), 'n_below_1M': int((dev.open_prev < 1e6).sum())},
 'input_rules': 'open_prev phai la so huu han > 0; ngoai khoang fit chi canh bao, khong chan',
 'source': {'dev_inputs_file': 'rq1_inputs_dev.csv', 'dev_inputs_sha256': sha(f'{T2}/data/rq1_inputs_dev.csv'), 'split_assignment_sha256': sha(f'{T2}/data/split_assignment.csv'),
            'task3_locked_config_sha256': sha(f'{T3}/locked_config_rq1.json'), 'task4_dev_fit_parameters_sha256': sha(f'{T4}/results/dev_fit_parameters.json'), 'task4_prescore_record_sha256': sha(f'{T4}/records/prescore_record.json')},
 'fit_reproduces_task4_params_max_abs_diff': float(d_), 'software': {'python': platform.python_version(), 'numpy': np.__version__, 'pandas': pd.__version__, 'predict_script': 'stdlib only (json, csv, math)'},
}
json.dump(art, open(f'{PL}/e0_fitted.json', 'w'), ensure_ascii=False, indent=1)
shutil.copy(f'{T2}/data/rq1_inputs_dev.csv', f'{PL}/data_dev/rq1_inputs_dev.csv')
ref = P[['transition_id', 'open_prev', 'Y_pred_E0', 'pct_pred_E0', 'Y_pred_median', 'pct_pred_median', 'Y_pred_Y0', 'pct_pred_Y0']]; ref.to_csv(f'{PL}/reference_predictions_task4.csv', index=False)
pd.DataFrame({'open_prev': [500000, 5000000, 20000000, 100000000]}).to_csv(f'{PL}/example_input.csv', index=False)
for fn in ('predict_e0.py', 'fit_e0.py'): pass

# ---------- 5. Kiem tra artifact: chay script du bao that ----------
def run(cmd, cwd=PL):
    return subprocess.run([sys.executable] + cmd, capture_output=True, text=True, cwd=cwd)
r = run(['predict_e0.py', '--artifact', 'e0_fitted.json', '--check', 'reference_predictions_task4.csv', '--check-output', 'artifact_check.csv'])
open(f'{LG}/artifact_check_output.txt', 'w').write(r.stdout + r.stderr)
chk('A01', 'script du bao tai tao E0, median, Y=0 tu 193 dong bang du bao Task 4 (dung sai 1e-9)', 'PASS', r.stdout.strip().splitlines()[-1] if r.stdout.strip() else r.stderr, r.returncode == 0)
r = run(['predict_e0.py', '--artifact', 'e0_fitted.json', '--input', 'example_input.csv', '--output', 'example_output.csv'])
chk('A02', 'vi du dau vao/dau ra chay thanh cong', 'exit 0', r.returncode, r.returncode == 0 and os.path.exists(f'{PL}/example_output.csv'))
r = run(['predict_e0.py', '--artifact', 'e0_fitted.json', '--open-prev', '20000000']); open(f'{LG}/example_single_prediction.json', 'w').write(r.stdout)
chk('A03', 'du bao don le open_prev = 20,000,000 chay thanh cong', 'exit 0', r.returncode, r.returncode == 0)
r = run(['fit_e0.py', '--artifact', 'e0_fitted.json', '--data', 'data_dev/rq1_inputs_dev.csv'])
open(f'{LG}/refit_output.txt', 'w').write(r.stdout + r.stderr)
chk('A04', 'fit_e0.py fit lai tu 725 dong dev, khop artifact (1e-9)', 'PASS', r.stdout.strip(), r.returncode == 0)
bad_ok = True; details = []
for bad in ('0', '-5', 'abc', 'nan', 'inf', ''):
    r = run(['predict_e0.py', '--artifact', 'e0_fitted.json', '--open-prev', bad]); details.append((bad, r.returncode)); bad_ok &= (r.returncode == 2)
chk('A05', 'dau vao khong hop le (0, am, chu, nan, inf, rong) bi tu choi voi ma thoat 2', 'moi truong hop exit 2', details, bad_ok)
stop_if_fail()

# ---------- 6. Bang ----------
T = lambda src, dst: shutil.copy(src, f'{TB}/{dst}')
T(f'{T2}/data/sample_funnel.csv', 'sample_funnel.csv'); T(f'{T2}/data/split_assignment.csv', 'split_assignment.csv')
ex = pd.read_csv(f'{T2}/data/exclusions.csv'); ex.groupby(['stage', 'reason']).size().reset_index(name='n_pairs').to_csv(f'{TB}/coverage_exclusions_summary.csv', index=False)
mem = pd.read_csv(f'{T2}/data/sample_rq1_membership.csv')
ss = mem.groupby(['role', 'stratum_open_prev']).agg(n_transitions=('transition_id', 'size'), n_franchises=('franchise_id', 'nunique')).reset_index()
tot = mem.groupby('role').agg(n_transitions=('transition_id', 'size'), n_franchises=('franchise_id', 'nunique')).reset_index().assign(stratum_open_prev='tat ca')
fo = mem[mem.role == 'dev'].groupby('fold').agg(n_transitions=('transition_id', 'size'), n_franchises=('franchise_id', 'nunique')).reset_index().assign(role='dev', stratum_open_prev=lambda d: 'fold ' + d.fold.astype(str)).drop(columns='fold')
pd.concat([tot, ss, fo])[['role', 'stratum_open_prev', 'n_transitions', 'n_franchises']].to_csv(f'{TB}/split_summary.csv', index=False)
chk('S01', 'bang split_summary: dev 725/449, test 193/113; tang >=1M dev 576, test 155', '725/449; 193/113', f"{int(tot[tot.role=='dev'].n_transitions.iloc[0])}/{int(tot[tot.role=='dev'].n_franchises.iloc[0])}; {int(tot[tot.role!='dev'].n_transitions.iloc[0])}/{int(tot[tot.role!='dev'].n_franchises.iloc[0])}",
    tot[tot.role == 'dev'].n_transitions.iloc[0] == 725 and tot[tot.role == 'dev'].n_franchises.iloc[0] == 449 and tot[tot.role != 'dev'].n_transitions.iloc[0] == 193 and tot[tot.role != 'dev'].n_franchises.iloc[0] == 113)
M3 = pd.read_csv(f'{T3}/results/metrics_models_dev.csv'); SEL = pd.read_csv(f'{T3}/results/selection_table.csv')
dsel = M3[['model', 'n_params', 'pooled_mae', 'rmse', 'fold1_mae', 'fold2_mae', 'fold3_mae', 'fold4_mae', 'mean_fold_mae', 'sd_fold_mae', 'franchise_mean_mae', 'mae_ge1M', 'mae_lt1M', 'pp_mae_median']].merge(SEL[['model', 'diff_vs_E0', 'folds_better_vs_E0', 'eligible']], on='model', how='left')
dsel['decision'] = dsel.model.map(lambda m: 'baseline' if m in ('Y0', 'median') else ('GIU (cau hinh duoc khoa)' if m == 'E0' else 'khong dat quy tac, khong thay E0'))
dsel.to_csv(f'{TB}/dev_selection_table.csv', index=False)
dv = {m: M3.set_index('model').loc[m] for m in mods}
rows = []
for m, lab in (('Y0', 'Y=0'), ('median', 'Median Y cua dev'), ('E0', 'E0: OLS log_open_prev')):
    t = TM[(TM.model == m) & (TM.scope == 'tat ca')].iloc[0]
    rows.append(dict(model=m, label=lab, dev_oof_mae_log=dv[m].pooled_mae, test_mae_log=t.mae_log, test_rmse_log=t.rmse_log, test_mae_log_franchise_mean=t.mae_log_franchise_mean,
                     test_pp_abs_err_median=t.pp_abs_err_median, test_pp_abs_err_mean=t.pp_abs_err_mean, n_test=int(t.n_transitions), n_test_franchises=int(t.n_franchises)))
MR = pd.DataFrame(rows); MR.to_csv(f'{TB}/main_results_table.csv', index=False)
for fn in ('test_metrics.csv', 'test_paired_comparison.csv', 'test_predictions_by_transition.csv', 'test_top_errors.csv', 'test_influential_summary.csv', 'dev_test_composition.csv', 'dev_vs_test_mae.csv', 'delta_mae_dev_vs_test.csv', 's1_s2_dev_summary.csv'):
    T(f'{T4}/results/{fn}', fn)
TM[TM.scope != 'tat ca'].to_csv(f'{TB}/test_error_by_stratum.csv', index=False)

# ---------- 7. Hinh ----------
for src, dst in ((f'{T4}/figures/fig1_test_mae.png', 'fig1_test_mae.png'), (f'{T4}/figures/fig1_data.csv', 'fig1_data.csv'), (f'{T4}/figures/fig2_delta_mae.png', 'fig2_delta_mae.png'), (f'{T4}/figures/fig2_data.csv', 'fig2_data.csv'),
                 (f'{T3}/figures/fig5_sensitivity.png', 'fig4_s1_s2_dev.png'), (f'{T3}/figures/fig5_data.csv', 'fig4_data.csv')):
    shutil.copy(src, f'{FG}/{dst}')
plt.rcParams.update({'font.family': 'DejaVu Sans', 'font.size': 9, 'axes.grid': True, 'grid.alpha': 0.3, 'axes.spines.top': False, 'axes.spines.right': False})
d3 = P[['transition_id', 'mau_chinh', 'quality_flag_any', 'Y_true', 'Y_pred_E0']]; d3.to_csv(f'{FG}/fig3_data.csv', index=False)
fig, ax = plt.subplots(figsize=(6.6, 5.6))
for s_, mk, c_ in (('open_prev ≥ 1M', d3.mau_chinh, '#1f3a5f'), ('open_prev < 1M', ~d3.mau_chinh, '#d98c2b')):
    ax.scatter(d3.Y_pred_E0[mk], d3.Y_true[mk], s=14, alpha=0.6, color=c_, label=f'{s_} (n={int(mk.sum())})')
fl = d3.quality_flag_any.astype(bool); ax.scatter(d3.Y_pred_E0[fl], d3.Y_true[fl], s=45, marker='x', color='red', label=f'có cờ chất lượng (n={int(fl.sum())})')
ax.plot([-11, 7], [-11, 7], 'k--', lw=1, label='y = x'); ax.axhline(0, color='grey', lw=0.6); ax.set_xlim(-1, 1); ax.set_ylim(-11, 7)
ax.set_xlabel('Y dự báo bởi E0 (log-change)'); ax.set_ylabel('Y thực tế = ln(Open_N) − ln(Open_N−1)')
ax.set_title('Hình 3. Test (193 transition): Y thực tế và Y dự báo của E0\nDự báo E0 trong khoảng −0,49 đến 0,65; Y thực tế từ −10,4 đến 6,6', fontsize=9); ax.legend(loc='lower right', fontsize=8)
fig.tight_layout(); fig.savefig(f'{FG}/fig3_test_actual_vs_pred.png', dpi=150); plt.close(fig)
chk('G01', 'du bao E0 tren test nam trong khoang x hien thi cua Hinh 3 (-1 den 1)', '[-1,1]', (float(d3.Y_pred_E0.min()), float(d3.Y_pred_E0.max())), d3.Y_pred_E0.between(-1, 1).all())

# ---------- 8. Tham chieu va nguon ----------
shutil.copy(f'{T3}/locked_config_rq1.json', f'{RF}/locked_config_rq1.json'); shutil.copy(f'{T4}/records/prescore_record.json', f'{RF}/prescore_record_task4.json')
shutil.copy(f'{T4}/results/dev_fit_parameters.json', f'{RF}/task4_dev_fit_parameters.json')
zr = []
for nm in ('task2_rq1', 'task3_rq1', 'task4_rq1'):
    p = f'/mnt/user-data/outputs/{nm}.zip'
    if os.path.exists(p): zr.append(dict(package=nm + '.zip', sha256=sha(p)))
pd.DataFrame(zr).to_csv(f'{RF}/source_package_hashes.csv', index=False)
stop_if_fail()
print(pd.DataFrame(V)[['id', 'status']].to_string(index=False)); print(MR.round(4).to_string(index=False))
